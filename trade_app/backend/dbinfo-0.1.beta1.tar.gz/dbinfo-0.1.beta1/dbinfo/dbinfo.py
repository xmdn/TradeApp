# -*- coding: utf-8 -*-
##############################################################################
#
#  DB Info, Database Information Tool
#  Copyright (C) 2013 MRDEV Software (<http://mrdev.com.ar>).
#
#  Author: Mariano Ruiz <mrsarm@gmail.com>
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with this programe.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import optparse
import sys

__version__ = '0.1.beta1'
__license__ = 'LGPL-3'

def error_db_not_implemented():
    sys.stderr.write("Database connector not implemented!")
    exit(-1)

def main(db='pg'):
    parser = optparse.OptionParser(version='%prog v' + __version__)
    if db=='pg':
        from postgres import connect, num_tables, tables_name, table_columns_name, table_columns, db_size
        from dbtable import PgDbTable as Table
        username_default = 'postgres'
        password_default = 'postgres'
        port_default = '5432'
    elif db=='my':
        from mysql import connect, num_tables, tables_name, table_columns_name, db_size
        username_default = 'root'
        password_default = 'admin'
        port_default = '3306'
    else:
        error_db_not_implemented()
    parser.add_option("-U", "--username", dest="username", help='database user name (default: "%s")' % (username_default,), default=username_default)
    parser.add_option("-W", "--password", dest="password", help='database password (default: "%s")' % (password_default,), default=password_default)
    parser.add_option("-d", "--dbname", dest="dbname", help='database name to connect', default=None)
    parser.add_option("-H", "--host", dest="host", help='database server host or socket directory (default: "localhost")', default="localhost")
    parser.add_option("-p", "--port", dest="port", help='database server port (default: "%s")' % (port_default,), default=port_default)
    parser.add_option("-t", "--table", dest="table", help='database table name', default=None)
    parser.add_option("-s", "--size", dest="size", action="store_true", help='database size', default=False)
    (options, args) = parser.parse_args()

    conn = connect(options)
    cur = conn.cursor()
    if options.table:
        if db=='my':
            print "Tables columns name:", table_columns_name(cur, options.table)
        else:
            tbl_path = options.table.split('.')
            if len(tbl_path) == 1:
                print Table(conn, options.table)
            else:
                print Table(conn, tbl_path[1], tbl_path[0])
    elif options.size:
        print "Database size:", db_size(cur, options.dbname)
    else:
        print "Number of tables:", num_tables(cur)
        print "Tables names:", tables_name(cur)
    exit(0)

def main_pg():
    main('pg')

def main_my():
    main('my')


if __name__=="__main__":
    main()
