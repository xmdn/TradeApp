# -*- coding: utf-8 -*-
##############################################################################
#
#  DB Info, Database Information Tool
#  Copyright (C) 2013 MRDEV Software (<http://mrdev.com.ar>).
#
#  Author: Mariano Ruiz <mrsarm@gmail.com>
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with this programe.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import psycopg2

def connect(options):
    conn = psycopg2.connect(database=options.dbname,
                            user=options.username,
                            password=options.password,
                            host=options.host,
                            port=options.port)
    return conn

def num_tables(cursor, table_schema='public'):
    cursor.execute(
        """SELECT count(*) FROM information_schema.tables
           WHERE table_schema=%s""", (table_schema,))
    num_tbls = cursor.fetchone()
    return num_tbls[0]

def tables_name(cursor, table_schema='public'):
    cursor.execute(
        """SELECT table_name FROM information_schema.tables
           WHERE table_schema=%s
           ORDER BY table_name""", (table_schema,))
    res = cursor.fetchall()
    tbls_name = [d[0] for d in res]
    return tbls_name

def table_columns_name(cursor, table_name, table_schema='public'):
    cursor.execute(
        """SELECT column_name 
           FROM information_schema.columns
           WHERE table_schema=%s AND table_name=%s
           ORDER BY column_name""", (table_schema, table_name,))
    res = cursor.fetchall()
    tbl_cols_name = [d[0] for d in res]
    return tbl_cols_name

def table_columns(cursor, table_name, table_schema='public'):
    cursor.execute(
        """SELECT column_name, data_type, is_nullable, column_default
           FROM information_schema.columns
           WHERE table_schema=%s AND table_name=%s
           ORDER BY column_name, is_nullable, column_default""", (table_schema, table_name,))
    res = cursor.fetchall()
    tbl_cols = [{'name': d[0], 'data_type': d[1], 'is_nullable': d[2] == 'YES', 'default': d[3] != None} for d in res]
    return tbl_cols

def db_size(cursor, dbname):
    """
    Return size in megabytes
    """
    cursor.execute(
        """SELECT pg_size_pretty(pg_database_size(pg_database.datname))
           FROM pg_database where
           datname=%s
        """, (dbname,))
    dbsize = cursor.fetchone()
    return dbsize[0]
