DbInfo
======

DbInfo is a Python 2.x library and command line tool
to extract information and provide util methods to
work with BBDDs.

Implemented in PostgreSQL, and MySQL (incomplete).

Development in progress.


Installation
------------

Install with pip in your env::

    $ pip install dbinfo

See ``INSTALL.rst`` guide to install from the sources.


About
-----

Project: https://launchpad.net/dbinfo

Authors: (2013-2014) Mariano Ruiz <mrsarm@gmail.cm>

License: LGPL-3
